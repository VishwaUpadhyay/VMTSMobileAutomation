package com.frameworkTrial;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class SampleJUnitTest {
	private  static final String YOUTUBE = "yt";
	private  static final String VM = "vm";
	protected WebDriver driver;
	Properties driverProp = new Properties();
	Properties websiteProp = new Properties();

	@Before
	public void initPageObjects() throws IOException {
        
		ClassLoader loader = Thread.currentThread().getContextClassLoader();
		InputStream is = loader.getResourceAsStream("chrome.properties");
		// load a properties file
		driverProp.load(is);
		System.setProperty(driverProp.getProperty("drive"), driverProp.getProperty("path"));
		driver = new ChromeDriver();
        System.out.println("Driver setup complete...");
		String website = System.getProperty("App");
		System.out.println("Application to be launched === " + website);
		if(VM.equals(website))
			websiteProp.load(loader.getResourceAsStream("virgin.properties"));
		else
			websiteProp.load(loader.getResourceAsStream("youtube.properties"));
		System.out.println("Application setup complete...");
	}

	@Test
	public void testHomePageHasAHeader() {
		System.out.println("Starting the application...");
		driver.get(websiteProp.getProperty("link"));
		System.out.println(driver.getTitle());
	}
}
