package com.org.vm;
import static org.junit.Assert.assertEquals;

import java.net.URL;
import java.util.concurrent.TimeUnit;
import org.apache.log4j.Logger;
import org.eclipse.jetty.client.api.Connection;
import org.junit.After;
import org.junit.Before;
import org.junit.Rule;
import org.junit.Test;
import org.junit.rules.TestName;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.ScreenOrientation;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testobject.appium.junit.TestObjectTestResultWatcher;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.NetworkConnectionSetting;
import io.appium.java_client.android.AndroidDriver;


//@TestObject(testObjectApiKey = "C5734DB513204E3588440085869A9B8B"/*, testObjectSuiteId = 12345*/)
//@RunWith(TestObjectAppiumSuite.class)
public class SampleJUnitTest {
	private static final String JavascriptExecutor = null;
    //public WebDriver driver = null;
    public AppiumDriver driver = null;
    
    
    private static Logger log = Logger.getLogger(SampleJUnitTest.class);
    
    @Rule
    public TestName testName = new TestName();

    @Rule
    public TestObjectTestResultWatcher resultWatcher = new TestObjectTestResultWatcher();
    
    @Before
    public void setUp() throws Exception {
   
    	System.out.println("Executing VM Kids application setup");
        DesiredCapabilities capabilities = new DesiredCapabilities();
        System.out.println("Start adding capabilities");
        capabilities.setCapability("testobject_api_key", "4181E8CFA465458483FB276D33F1E496");
        //capabilities.setCapability("testobject_test_report_id", resultWatcher.getTestReportId());
        capabilities.setCapability("platformName", "Android");
        capabilities.setCapability("testobject_device", "Motorola_Moto_E_2nd_gen_free");
        capabilities.setCapability("appiumVersion","1.6.5");
        //capabilities.setCapability("phoneOnly", "false");
        //capabilities.setCapability("tabletOnly", "false");
        //capabilities.setCapability("privateDevicesOnly", "false");
        //capabilities.setCapability("testobject_app_id",1);
        //driver = new AndroidDriver(new URL("http://appium.testobject.com/wd/hub"), capabilities);
        //driver = new AndroidDriver(new URL("https://us1.appium.testobject.com/wd/hub"), capabilities);
        System.out.println("Creating driver/Allocating device........");
        driver = new AndroidDriver<WebElement>(new URL("https://eu1.appium.testobject.com/wd/hub"), capabilities);
        //driver = new AndroidDriver<WebElement>(TestObjectCapabilities.TESTOBJECT_APPIUM_ENDPOINT, capabilities);
        resultWatcher.setAppiumDriver(driver);
        System.out.println("driver created launching the app........");
        driver.launchApp();
        System.out.println("App lunched");
        log.info(testName.getMethodName() + " STARTING - Live view: " + driver.getCapabilities().getCapability("testobject_test_live_view_url"));
        System.out.println("Setup Complete....");
    }
    
    
    
	@After
	public void tearDown() {
		// The watcher will take care of quitting the driver.
		if (driver != null) {
			driver.quit();
		}
	}
	
	@org.junit.Test
    public void verifyScreenOrientation() throws InterruptedException {
		System.out.println("Test started....");
		driver.getScreenshotAs(OutputType.FILE);
		assertEquals(ScreenOrientation.LANDSCAPE, driver.getOrientation());
		System.out.println("Test ended....");
    }	
}
